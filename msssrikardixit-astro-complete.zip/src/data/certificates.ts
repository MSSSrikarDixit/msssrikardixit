export type Cert = {
  id: string;
  title: string;
  issuer: string;
  issued: string;
  score?: string;
  credentialId?: string;
  suggestedFilename?: string;
  driveLink?: string;
};

const DRIVE = 'https://drive.google.com/drive/folders/REPLACE_WITH_YOUR_FOLDER_ID';

export const certificates: Cert[] = REPLACE_WITH_FULL_LIST_FROM_PREVIOUS_ANSWER;

export default certificates;