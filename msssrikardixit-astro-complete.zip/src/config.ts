export const DRIVE_FOLDER_LINK = 'https://drive.google.com/drive/folders/REPLACE_WITH_YOUR_FOLDER_ID';
export const SITE_TITLE = 'Missula S. S. S. R. Dixit — Portfolio';